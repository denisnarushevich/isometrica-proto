var config = module.exports;

config["tests"] = {
    rootPath: '../',
    environment: 'node',
    sources: ['simplex-noise.js'],
    tests: ['test/*-test.js']
};
